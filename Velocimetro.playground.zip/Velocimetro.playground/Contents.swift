//: Tarea

import UIKit

enum Velocidades : Int {
    case Apagado = 0 , VelocidadBaja = 20 , VelicidadMedia = 50 , VelocidadAlta = 120
    


init (velocidadInicial : Velocidades){
    self = velocidadInicial
}
}
class Auto {
    var velocidad : Velocidades
    
    init(){
        velocidad = Velocidades ( velocidadInicial : .Apagado)
    }
        func cambioDeVelocidad( ) -> (actual : Int, velocidadEnCadena: String)   {
            
            var mensaje = ""
            
            let actual = velocidad.rawValue
            switch velocidad {
            case .Apagado :
                velocidad = .VelocidadBaja
            mensaje = "Apagado"
            case .VelocidadBaja :
                velocidad = .VelicidadMedia
            mensaje = "Velocidad Baja"
            case .VelicidadMedia :
                velocidad = .VelocidadAlta
            mensaje = "Velocidad Media"
            case .VelocidadAlta :
                velocidad = .Apagado
            mensaje = "Velocidad Alta"
        }
            return (actual, mensaje)
        }
    }

    let auto = Auto()
    
    for i in 1...20 {
    let autoResultado = auto.cambioDeVelocidad()
    print("\(i). \(autoResultado.actual), \(autoResultado.velocidadEnCadena)")
}