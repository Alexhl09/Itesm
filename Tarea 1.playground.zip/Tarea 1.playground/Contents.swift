//: Playground - noun: a place where people can play

import UIKit

var numeros = 0...100

for numero in numeros {
    if numero > 30 && numero < 40 {
        print ("\(numero)\t\"Viva swift")
    } else if numero == 0 {
        print ("\(numero)\t\"Cero")
    }else if numero % 5 == 0 {
        print ("\(numero)\t\"Bingo!!!")
    }else if numero % 2 == 0 {
        print ("\(numero)\t\"par")
    } else if numero % 2 != 0 {
        print ("\(numero)\t\"impar")
    }
    }


